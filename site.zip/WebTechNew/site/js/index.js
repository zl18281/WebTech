// Navigation bar

$(".navbar-nav > li > a").last().css("background-color", "transparent");
