This is a project for the course of web technology.

2019-4-22
We finished the main page of the website.

2019-5-26
We finished all the functions of the website.

note for running:

Step 1: alter directory to the 'WebTechNew' folder

Step 2: npm install

Step 3: node server.js

Step 3: visit through port 3000
